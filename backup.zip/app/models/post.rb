class Post < ApplicationRecord

	validates :title, presence: true
	validates :content, presence: true

	has_many :comments, :dependent => :destroy

	has_many_attached :images, :dependent => :destroy

	validates :images, content_type: ['image/png', 'image/jpg', 'image/jpeg']
	
	attr_accessor :keep_images

	def thumbnail input
		return self.images[input].variant(resize: '200x200').processed
	end

end
